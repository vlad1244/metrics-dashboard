# Metrics Dashboard (static)

Это статическая версия твоего HTML-блока из Tilda.
Открывай `index.html` локально или деплой на Cloudflare Pages / GitHub Pages / Netlify.

## ВАЖНО (CORS)
После переезда с Tilda на новый домен, Cloud Run API должен разрешать запросы с нового origin.
Если в браузере в консоли будет ошибка CORS — добавь на backend CORS headers.

Express пример:
```js
app.use((req,res,next)=>{
  res.setHeader('Access-Control-Allow-Origin', '*'); // или конкретный домен
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});
```
